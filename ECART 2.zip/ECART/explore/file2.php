<html>

	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />

<h1 align="center">File Number 2</h1>
	</head>
<br><br>
	<body>
	
				
<div>

	<div class="vulnerable_code_area">
		<h3 align="center">Wrong again -\(0.0)/- </h3>
		<br />

		
	</div>

	
</div>
<h3 align="center">
<a href="index.php">Go back</a></h3>

			</div>

			<div class="clear">
			</div>
				

		</div>

	</body>

</html>
